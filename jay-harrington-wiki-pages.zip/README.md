# Jay Harrington Wiki

Welcome to the fan-managed **Jay Harrington Wiki**, brought to you by the [jayfansite](https://github.com/jayfansite) community. Here you'll find verified information, media galleries, and access to become an official fan.

---

## 👤 About Jay Harrington

- **Full Name:** James H. Harrington III  
- **Born:** November 15, 1971 — Wellesley, Massachusetts, USA  
- **Profession:** Actor  
- **Notable Roles:**
  - Sgt. David "Deacon" Kay – *S.W.A.T.* (CBS, 2017–Present)  
  - Ted Crisp – *Better Off Ted* (ABC, 2009–2010)  
  - Recurring on *Private Practice*, *Desperate Housewives*, *The Shield*

---

## 📂 Wiki Pages

- [Career & Early Life](wiki/Career.md)  
- [Complete Filmography](wiki/Filmography.md)  
- [Fan Verification Process](wiki/FanVerification.md)  
- [Media & Gallery](wiki/Gallery.md)

---

## ✅ Fan Verification

Become a verified fan of Jay Harrington by completing:
- [Fan Verification Process](wiki/FanVerification.md)

---

## 🛠 Contributing

Love Jay? Help us improve this wiki:  
1. Fork this repo  
2. Edit or add content  
3. Submit a Pull Request  
OR contact us at: abelhockgeneralmanager@gmail.com

---

**© 2025 JayFansite | Powered by LAPD / CBS / SWAT Fan Access Department**
