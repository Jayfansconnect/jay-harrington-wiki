# Media & Gallery

Explore these official and fan-captured images of Jay Harrington:

> A media gallery is under development — check back soon!

---

You can contribute:
- Red carpet photos  
- Promotional stills  
- Fan art or badges
