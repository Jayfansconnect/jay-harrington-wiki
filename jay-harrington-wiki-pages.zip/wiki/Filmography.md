# Filmography

## Television
| Year | Show | Role |
|------|------|------|
| 2017–Present | *S.W.A.T.* (CBS) | Sgt. David “Deacon” Kay |
| 2009–2010 | *Better Off Ted* (ABC) | Ted Crisp |
| 2008 | *Private Practice* | Dr. Wyatt Lockhart |
| 2006 | *Desperate Housewives* | Dr. Ron McCready |
| 2005 | *The Inside* | Paul Ryan |
| 2004 | *Summerland* | Dr. Simon O’Keefe |
| 2003 | *Coupling* (US) | Steve Taylor |

## Film
- **American Reunion** (2012) – Dr. Ron  
- **A Plumm Summer** (2007) – Mick Plumm  
- **Anywhere But Here** (1999) – Waiter

## Stage
- Numerous regional theatre roles early in his career
