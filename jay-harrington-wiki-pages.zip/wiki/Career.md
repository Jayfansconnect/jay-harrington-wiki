# Career & Early Life

**Jay Harrington** began life in Wellesley, Massachusetts, where he developed a passion for acting.  

## 🎓 Education
Graduated from **Syracuse University**, B.F.A. in Theatre.

## 🎭 Early Work
Performed in regional theatre before breaking into television in the early 2000s.

## 📺 Television Career Highlights
- **S.W.A.T.** (CBS, 2017– ) as Sgt. David "Deacon" Kay  
- **Better Off Ted** (ABC, 2009–10) – Ted Crisp  
- **Private Practice** (2008) – Dr. Wyatt Lockhart  
- Guest roles in *Desperate Housewives*, *The Shield*, *Summerland*, *The Inside*, *Coupling*

## 🎬 Film Appearances
- *American Reunion* (2012) – Dr. Ron  
- *A Plumm Summer* (2007) – Mick Plumm

## 🏆 Awards & Recognition
– *Earned a dedicated fan base for his role on S.W.A.T.*  
– *Praised for his versatility in both comedic and dramatic performances*
