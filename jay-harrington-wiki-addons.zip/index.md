---
title: Jay Harrington Wiki
---

# 🎬 Jay Harrington Wiki

Welcome to the official **Jay Harrington Wiki**, powered by fans from [jayfansite](https://github.com/jayfansite).

Explore:
- [Career](wiki/Career.md)
- [Filmography](wiki/Filmography.md)
- [Fan Verification Form](verification.html)
- [Verified Badges](badges.html)
- [Gallery](wiki/Gallery.md)

> Maintained by LAPD/CBS/SWAT Fan Access Department – Los Angeles HQ.
